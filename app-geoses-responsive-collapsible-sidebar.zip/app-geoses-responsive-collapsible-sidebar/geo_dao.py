#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun  8 10:54:21 2022

@author: wesleyz
"""
import pandas as pd

df = round(pd.read_csv("merge_geoses_indicadores_obstetricos.csv", sep=';'),2)

templates = [
    "bootstrap",
    "minty",
    "pulse",
    "flatly",
    "quartz",
    "cyborg",
    "darkly",
    "vapor",
]

optConti = ['Codigo',
 
 'Nascimentos',
 'Porc_prematuros',
 'Porc_cesareas',
 'Porc_grav_multipla',
 'Porc_anomalias',
 'Porc_nenhuma_consulta',
 'Porc_consulta7mais',
 'Porc_feminino',
 'Porc_raca_mae_branca',
 'Porc_raca_mae_negra',
 'Porc_peso_menor_2500',
 'Porc_apgar1_menor_7',
 'Porc_apgar5_menor_7',
 'Taxa_mort_materna',
 'Taxa_mort_infantil',
 'Taxa_mort_neonatal',
 'Taxa_mort_neonatal_precoce',
 'Taxa_mort_neonatal_tardia',
 'Taxa_mort_pos_neonatal', 
 'GeoSES',
 'educação',
 'mobilidade',
 'pobreza',
 'privacao_material',
 'riqueza',
 'renda',
 'segregacao', 
 'Clusters']