"""
This app creates a collapsible, responsive sidebar layout with
dash-bootstrap-components and some custom css with media queries.

When the screen is small, the sidebar moved to the top of the page, and the
links get hidden in a collapse element. We use a callback to toggle the
collapse when on a small screen, and the custom CSS to hide the toggle, and
force the collapse to stay open when the screen is large.

dcc.Location is used to track the current location, a callback uses the current
location to render the appropriate page content. The active prop of each
NavLink is set automatically according to the current pathname. To use this
feature you must install dash-bootstrap-components >= 0.11.0.

For more details on building multi-page Dash applications, check out the Dash
documentation: https://dash.plot.ly/urls
"""
import dash
import dash_bootstrap_components as dbc
from dash import Input, Output, State, dcc, html
import base64
import os
from geo_dao import templates, df, pd,optConti
import plotly.graph_objs as go


image_filename = 'logooobr.png' # replace with your own image
#encoded_image = base64.b64encode(open(image_filename, 'rb').read())
#PLOTLY_LOGO = "'data:image/png;base64,{}'.format(encoded_image)"

app = dash.Dash(
    external_stylesheets=[dbc.themes.SKETCHY],
    # these meta_tags ensure content is scaled correctly on different devices
    # see: https://www.w3schools.com/css/css_rwd_viewport.asp for more
    meta_tags=[
        {"name": "viewport", "content": "width=device-width, initial-scale=1"}
    ],
)

controls = dbc.Card(
    [
        html.Div(
            [
                dbc.Label("X variable"),
                dcc.Dropdown(
                    id="x-variable",
                    options=optConti,
                    value="Nascimentos",
                ),
            ]
        ),
        html.Div(
            [
                dbc.Label("Y variable"),
                dcc.Dropdown(
                    id="y-variable",
                    options=optConti[-10:],
                    value="GeoSES",
                ),
            ]
        ),
        html.Div(
            [
                dbc.Label("Legenda",style={'display': 'none'}),
                dcc.Dropdown(
                    id="tipoLegenda",
                    options=optConti,
                    value="Clusters",style={'display': 'none'}
                ),
            ]
        ),
        html.Div(
            [   
                dbc.Label("Gráfico", style={'display': 'none'}),
                dcc.Dropdown(
                    id="tipoGrafico",
                    options=['pontos', 'barra', 'box'         
                    ],
                    value="pontos",style={'display': 'none'},
                ),
            ]
        ),
    ],
    body=True,
)






# we use the Row and Col components to construct the sidebar header
# it consists of a title, and a toggle, the latter is hidden on large screens
sidebar_header = dbc.Row(
    [
        html.Img(src=app.get_asset_url(image_filename), style={'width':'60%'}),
        
        dbc.Col(html.H2("", className="display-4")),
        dbc.Col(
            [
                html.Button(
                    # use the Bootstrap navbar-toggler classes to style
                    html.Span(className="navbar-toggler-icon"),
                    className="navbar-toggler",
                    # the navbar-toggler classes don't set color
                    style={
                        "color": "rgba(0,0,0,.5)",
                        "border-color": "rgba(0,0,0,.1)",
                    },
                    id="navbar-toggle",
                ),
                html.Button(
                    # use the Bootstrap navbar-toggler classes to style
                    html.Span(className="navbar-toggler-icon"),
                    className="navbar-toggler",
                    # the navbar-toggler classes don't set color
                    style={
                        "color": "rgba(0,0,0,.5)",
                        "border-color": "rgba(0,0,0,.1)",
                    },
                    id="sidebar-toggle",
                ),
            ],
            # the column containing the toggle will be only as wide as the
            # toggle, resulting in the toggle being right aligned
            width="auto",
            # vertically align the toggle in the center
            align="center",
        ),
    ]
)

sidebar = html.Div(
    [
        sidebar_header,
        # we wrap the horizontal rule and short blurb in a div that can be
        # hidden on a small screen
        html.Div(
            [
                html.Hr(),
                html.P(
                    "Painel de Indicadores Socioeconômico e Obstétricos"
                    ,
                    className="lead",
                ),
            ],
            id="blurb",
        ),
        # use the Collapse component to animate hiding / revealing links
        dbc.Collapse(
            dbc.Nav(
                [
                    dbc.NavLink("Início", href="/", active="exact"),
                    dbc.NavLink("GeoSES", href="/page-1", active="exact"),
                    dbc.NavLink("IBGE", href="/page-2", active="exact"),
                ],
                vertical=True,
                pills=True,
            ),
            id="collapse",
        ),
    ],
    id="sidebar",
)

content = html.Div(id="page-content")

#app.layout = html.Div([dcc.Location(id="url"), sidebar, content])

app.layout = dbc.Container(
    [
     html.Div([dcc.Location(id="url"), sidebar, content])
     ], fluid=True,
    )


@app.callback(Output("page-content", "children"), [Input("url", "pathname")])
def render_page_content(pathname):
    if pathname == "/":
        return html.P("Bem vindo o Painel do Observatório Obstétrico Brasileiro!")
    elif pathname == "/page-1":
        return dbc.Row(
            [
                dbc.Col(controls, md=4),
                dbc.Col(children=(html.H3("GeoSES"),
                        dcc.Graph(id="cluster-graph")), md=8),
            ],
            align="center",
        )#html.P("This is the content of page 1. Yay!")
    elif pathname == "/page-2":
        return html.P("Em construção... ")
    # If the user tries to reach a different page, return a 404 message
    return dbc.Jumbotron(
        [
            html.H1("404: Not found", className="text-danger"),
            html.Hr(),
            html.P(f"The pathname {pathname} was not recognised..."),
        ]
    )




@app.callback(
    Output("cluster-graph", "figure"),
    [
        Input("x-variable", "value"),
        Input("y-variable", "value"),
        Input("tipoLegenda", "value"),
        Input("tipoGrafico", "value"),
    ],
)
def make_graph(x, y, tipoLegenda, tipoGrafico):
    #print(x, y, tipoLegenda, tipoGrafico)
    # minimal input validation, make sure there's at least one cluster
    
    if tipoGrafico=='pontos':
        data = [
            go.Scatter(
                x=df[x],
                y=df[y],
                mode="markers",
                #marker={"color": "#000", "size": 12, "symbol": "diamond"},
                #name="Cluster centers",
                #fillcolor=df["Clusters"],
                #hover_name="Nome_Município",
                #template="sketchy",
                #log_x=True 
                    )
                ]
        layout = {"xaxis": {"title": x}, "yaxis": {"title": y}}


        return go.Figure(data=data, layout=layout)

    

  
    

# make sure that x and y values can't be the same variable
def filter_options(v):
    """Disable option v"""
    return [
        {"label": col, "value": col, "disabled": col == v}
        for col in df.columns
    ]


# functionality is the same for both dropdowns, so we reuse filter_options
app.callback(Output("x-variable", "options"), [Input("y-variable", "value")])(
    filter_options
)
app.callback(Output("y-variable", "options"), [Input("x-variable", "value")])(
    filter_options
)








@app.callback(
    Output("sidebar", "className"),
    [Input("sidebar-toggle", "n_clicks")],
    [State("sidebar", "className")],
)
def toggle_classname(n, classname):
    if n and classname == "":
        return "collapsed"
    return ""


@app.callback(
    Output("collapse", "is_open"),
    [Input("navbar-toggle", "n_clicks")],
    [State("collapse", "is_open")],
)
def toggle_collapse(n, is_open):
    if n:
        return not is_open
    return is_open


if __name__ == "__main__":
    app.run_server(port=8888, host="0.0.0.0", debug=True)
