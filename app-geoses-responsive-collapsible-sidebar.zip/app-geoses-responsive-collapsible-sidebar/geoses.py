#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jun  4 13:46:22 2022

@author: wesleyz
"""
from dash import Dash, html, dcc,Input, Output, State, callback_context, dash_table
from geo_dao import templates, df
import plotly.express as px
import dash_bootstrap_components as dbc
from dash_bootstrap_templates import load_figure_template
import pandas as pd



load_figure_template(templates)

'''
external_stylesheets = [
    'https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css',
    {
        'href': 'https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css',
        'rel': 'stylesheet',
        'integrity': 'sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T',
        'crossorigin': 'anonymous'
    }
]

external_scripts = [
    'https://www.google-analytics.com/analytics.js',
    {'src': 'https://cdn.polyfill.io/v2/polyfill.min.js'},
    {
        'src': 'https://cdnjs.cloudflare.com/ajax/libs/lodash.js/4.17.10/lodash.core.js',
        'integrity': 'sha256-Qqd/EfdABZUcAxjOkMi8eGEivtdTkh3b65xCZL4qAQA=',
        'crossorigin': 'anonymous'
    }
]

# external CSS stylesheets
external_stylesheets = [
    'https://codepen.io/chriddyp/pen/bWLwgP.css',
    {
        'href': 'https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css',
        'rel': 'stylesheet',
        'integrity': 'sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO',
        'crossorigin': 'anonymous'
    }
]
'''

def generate_table(dataframe, max_rows=10):
    return html.Table([
        html.Thead(
            html.Tr([html.Th(col) for col in dataframe.columns])
        ),
        html.Tbody([
            html.Tr([
                html.Td(dataframe.iloc[i][col]) for col in dataframe.columns
            ]) for i in range(min(len(dataframe), max_rows))
        ])
    ])



df['Clusters'] = df['Clusters'].astype('category')


#app = Dash(__name__, 
#           external_scripts=external_scripts,
#           external_stylesheets=external_stylesheets)

app = Dash(__name__, external_stylesheets=[dbc.themes.VAPOR,dbc.icons.FONT_AWESOME])


fig = px.box(df, x="Nascimentos", y="GeoSES",
                  color="Clusters", hover_name="Nome_Município",template="vapor",
                 log_x=True )


fig2 = px.scatter(df, x="pobreza", y="GeoSES",
                  color="UF_x", hover_name="Nome_Município",template="vapor",
                 log_x=True )


options = list(df['Clusters'].unique())
options.sort()





#html.H1('Painel de Exploração de Dados - ENEM - 1998 a 2019', style={'textAlign': 'center', 'color': '#7FDBFF'})
varString = pd.DataFrame(df.dtypes)[pd.DataFrame(df.dtypes)[0]!=object]
varString_ = pd.DataFrame(df.dtypes)[pd.DataFrame(df.dtypes)[0]==object]


accordion = html.Div(
    dbc.Accordion(
        [
            dbc.AccordionItem(
                dcc.Dropdown(optConti,
                             optConti[3],
                             id='featX'),
                title="Eixo X",
            ),
            dbc.AccordionItem(
                dcc.Dropdown(optConti,
                                    optConti[2],
                                    id='featY'),
                title="Eixo Y",
            ),
            dbc.AccordionItem(
                dcc.Dropdown([ 'Nome_UF',
                 'Nome Região Geográfica Intermediária',
                 'Nome Região Geográfica Imediata',
                 'Nome_Mesorregião',
                 'Nome_Microrregião']+['Clusters'],
                             'Clusters',
                             id='color'),
                title="Legenda - Cores",
            ),
            dbc.AccordionItem(
                
             html.Div(children=generate_table(df),style={
                 'textAlign': 'center',
                 'color': 'primary'
             }),title='Tabela'),
        ],
        always_open=True,
    )
)





app.layout = html.Div(children=[html.Blink(children='Observatório Obstétrico'),
                                
                                html.Div(children='GeoSES'), 
                               
                                
                                
                                
                                
                                dcc.Graph(id='example-graph-2',
                                          figure=fig2
                                          ),
                                accordion,
                                
                                #html.Label(children='Selecione a variável do Eixo X')
                                ])




@app.callback(
    Output('example-graph-2', 'figure'),
    Input('featX', 'value'),
    Input('featY', 'value'),
    Input('color', 'value'))    
def update_graph(featX, featY,
                 color ):
    #dff = df[df['Year'] == year_value]

    fig = px.scatter(df, x=featX, y=featY,
                      color=color, hover_name="Nome_Município",
                      #template="vapor",
                     log_x=True )

    return fig



if __name__ == '__main__':
    app.run_server(debug=True)